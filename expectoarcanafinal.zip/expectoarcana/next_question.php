<?php
session_start();
include("connection.php");
include("functions.php");

// Check if we are starting the quiz and set the initial question ID
if (isset($_POST['startQuiz'])) {
    $_SESSION['current_question_id'] = 0; // Initialize with a default or fetch from database
}

// Fetch the current question and options based on the `current_question_id`
$questionQuery = "SELECT * FROM questions WHERE id = ?";
$stmt = $con->prepare($questionQuery);
$stmt->bind_param('i', $_SESSION['current_question_id']);
$stmt->execute();
$questionResult = $stmt->fetch_assoc();

// Fetch options for the current question
$optionsQuery = "SELECT * FROM options WHERE question_id = ?";
$optionsStmt = $conn->prepare($optionsQuery);
$optionsStmt->bind_param('i', $_SESSION['current_question_id']);
$optionsStmt->execute();
$options = $optionsStmt->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Quiz Page</title>
</head>
<body>
    <h1><?php echo $questionResult['question_text']; ?></h1>
    <form action="check_answer.php" method="post">
        <?php foreach ($options as $option): ?>
            <label>
                <input type="radio" name="optionId" value="<?php echo $option['id']; ?>">
                <?php echo $option['option_text']; ?>
            </label><br>
        <?php endforeach; ?>
        <button type="submit" name="submitAnswer">Submit</button>
    </form>
</body>
</html>

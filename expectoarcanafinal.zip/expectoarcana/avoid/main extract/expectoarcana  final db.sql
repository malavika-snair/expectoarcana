-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 07:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expectoarcana`
--
CREATE DATABASE IF NOT EXISTS `expectoarcana` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `expectoarcana`;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

DROP TABLE IF EXISTS `contact_us`;
CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `contact_us`
--

TRUNCATE TABLE `contact_us`;
--
-- Dumping data for table `contact_us`
--

INSERT DELAYED IGNORE INTO `contact_us` (`id`, `name`, `email`, `message`) VALUES
(1, 'arya khanna', 'arya@yahoo.com', 'hello i want to test sending messages'),
(2, 'Louis Keith', 'louiskeith@gmail.com', 'hello just wanted to drop in to say that');

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
CREATE TABLE IF NOT EXISTS `games` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `games`
--

TRUNCATE TABLE `games`;
--
-- Dumping data for table `games`
--

INSERT DELAYED IGNORE INTO `games` (`game_id`, `game_name`, `description`) VALUES
(1, 'Wizard\'s Duel', 'Play Tic-Tac-Toe with a friend or against the computer.'),
(2, 'Mystical Mosaic Quest', 'Complete the magical mosaic puzzles!'),
(3, 'Quizzical', 'Test your wizarding knowledge with our quizzes!');

-- --------------------------------------------------------

--
-- Table structure for table `highscores`
--

DROP TABLE IF EXISTS `highscores`;
CREATE TABLE IF NOT EXISTS `highscores` (
  `highscore_id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY (`highscore_id`),
  KEY `game_id` (`game_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `highscores`
--

TRUNCATE TABLE `highscores`;
--
-- Dumping data for table `highscores`
--

INSERT DELAYED IGNORE INTO `highscores` (`highscore_id`, `game_id`, `user_id`, `score`) VALUES
(2, 3, 66662477, 0),
(3, 3, 59437240782, 0),
(4, 3, 9223372036854775807, 0),
(5, 3, 39205233567371, 0);

-- --------------------------------------------------------

--
-- Table structure for table `magic`
--

DROP TABLE IF EXISTS `magic`;
CREATE TABLE IF NOT EXISTS `magic` (
  `magic_id` int(11) NOT NULL AUTO_INCREMENT,
  `spell_name` varchar(50) NOT NULL,
  `meaning` text DEFAULT NULL,
  `audio_file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`magic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `magic`
--

TRUNCATE TABLE `magic`;
--
-- Dumping data for table `magic`
--

INSERT DELAYED IGNORE INTO `magic` (`magic_id`, `spell_name`, `meaning`, `audio_file`) VALUES
(1, 'Aberto', 'Opens locked doors', 'aberto (ah-behr-toh)'),
(2, 'Accio', 'Summons objects', 'accio (ah-kee-oh)'),
(3, 'Aguamenti', 'Summons water', 'aguamenti (ah-gwah-men-tee)'),
(4, 'Alohomora', 'Unlocks objects', 'alohomora (ah-loh-ho-mor-ah)'),
(5, 'Anapneo', 'Clears someone’s airway', 'anapneo (ah-nap-nee-oh)'),
(6, 'Aparecium', 'Reveals secret, written messages', 'aparecium (ah-par-ee-see-um)'),
(7, 'Apparate', 'A non-verbal transportation spell that allows a witch or wizard to instantly travel on the spot and appear at another location.', 'apparate (ah-pah-rah-tay)'),
(8, 'Ascendio', 'Propels someone into the air', 'ascendio (ah-sen-dee-oh)'),
(9, 'Avada Kedavra', 'Also known as The Killing Curse, the most evil spell in the wizarding world; one of three Unforgivable Curses; Harry Potter is the only known witch or wizard to survive it.', 'avada kedavra (ah-vah-dah keh-dah-vrah)'),
(10, 'Avis', 'Conjures a small flock of birds', 'avis (ah-vees)'),
(11, 'Bat-Bogey Hex', 'Turns the target’s boogers into bats', 'bat bogey hex (bat-boh-gee-hex)'),
(12, 'Bombardo', 'Create an explosion', 'bombardo (bom-bar-doh)'),
(13, 'Brackium Emendo', 'Heals broken bones', 'brackium emendo (bra-kee-um eh-men-doh)'),
(14, 'Capacious Extremis', 'Known as the Extension Charm, it’s a complicated spell that can greatly expand or extend the capacity of an object or space without affecting it externally', 'capacious extremis (kuh-pay-shus eks-tree-mis)'),
(15, 'Confundo', 'Known as the Confundus Charm, it causes confusion of the target', 'confundo (kon-foon-doh)'),
(16, 'Conjuctivitis Curse', 'Affects the eyes and sight of a target', 'conjuctivitis curse (kon-junk-tuh-vy-tis kurs)'),
(17, 'Crinus Muto', 'Changes hair color and style', 'crinus muto (kree-nus moo-toh)'),
(18, 'Crucio', 'One of three Unforgivable Curses,it causes unbearable pain in the target', 'crucio (kroo-shee-oh)'),
(19, 'Diffindo', 'Used to precisely cut an object', 'diffindo (di-fin-doh)'),
(20, 'Disillusionment Charm', 'Causes the target to take on the appearance of its surroundings', 'disillusionment charm (dis-ih-loo-zhun-ment charm)'),
(21, 'Disapparate', 'A non-verbal transportation spell that allows a witch or wizard to instantly travel on the spot and leave for another location', 'disapparate (dis-ap-uh-rate)'),
(22, 'Engorgio', 'Causes rapid growth in the targeted object', 'engorgio (en-gor-jee-oh)'),
(23, 'Episkey', 'Heals minor injuries', 'episkey (eh-pis-kee)'),
(24, 'Expecto patronum', 'The Patronus Charm is a powerful projection of hope and happiness that drives away Dementors; a corpeal Patronus takes the respective animal form of the caster, while a non-corpeal appears as a wisp of light', 'expecto patronum (ex-pek-toh puh-troh-num)'),
(25, 'Erecto', 'Allows a witch or wizard to build a structure, like a tent', 'erecto (uh-rek-toh)'),
(26, 'Evanesco', 'Vanishes objects', 'evanesco (eh-vuh-nes-koh)'),
(27, 'Expelliarmus', 'Forces an opponent to drop whatever is in their possession', 'expelliarmus (ex-pel-ee-ar-mus)'),
(28, 'Ferula', 'A healing charm that conjures wraps and bandages for wounds', 'ferula (feh-roo-lah)'),
(29, 'Fidelius Charm', 'A complex charm that conceals a secret into the soul of a chosen “Secret Keeper”, if a location is the subject of concealment,it becomes undetectable to others', 'fidelius charm (fi-dee-lee-us charm)'),
(30, 'Fiendfyre Curse', 'Conjures destructive, enormous enchanted flames', 'fiendfyre curse (feend-fahy-er kurs)'),
(31, 'Finite Incantatem', 'A general counter-spell that’s used to reverse or counter already cast charms', 'finite incantatem (fai-nahyt in-kan-tah-tem)'),
(32, 'Furnunculus Curse', 'A jinx that causes a breakout of boils or pimples', 'furnunculus curse (fer-nuhng-kyuh-lus kurs)'),
(33, 'Geminio', 'Duplicates objects', 'geminio (jem-in-ee-oh)'),
(34, 'Glisseo', 'Transforms a staircase into a slide', 'glisseo (glee-see-oh)'),
(35, 'Homenum Revelio', 'Reveals the presence of another person', 'homenum revelio (hoh-mee-nuhm re-vee-lee-oh)'),
(36, 'Homonculus Charm', 'Detects anyone’s true identity and location on a piece of parchment; used to create the Marauder’s Map', 'homonculus charm (ho-mon-kyuh-lus charm)'),
(37, 'Immobulus', 'Immobilizes living targets', 'immobulus (im-moh-byoo-lus)'),
(38, 'Impedimenta', 'A temporary jinx that shows the movement of the target', 'impedimenta (im-ped-uh-men-tuh)'),
(39, 'Incarcerous', 'Conjures ropes', 'incarcerous (in-kar-ser-uhs)'),
(40, 'Imperio', 'One of the three Unforgivable Curses, it places the target under the complete control of the caster', 'imperio (im-peer-ee-oh)'),
(41, 'Impervius', 'Makes an object waterproof', 'impervius (im-pur-vee-us)'),
(42, 'Incendio', 'Conjures flames', 'incendio (in-sen-dee-oh)'),
(43, 'Langlock', 'Causes the target’s tongue to stick to the roof of their mouth', 'langlock (lang-lok)'),
(44, 'Legilimens', 'Invading or navigating another’s mind', 'legilimens (leh-jih-lih-mens)'),
(45, 'Levicorpus', 'Levitates the target by their ankle', 'levicorpus (leh-vih-kor-pus)'),
(46, 'Locomotor Mortis', 'The Leg-Locker curse bounds the target’s legs', 'locomotor mortis (loh-koh-moh-tor mawr-tis)'),
(47, 'Lumos', 'Illuminates the caster’s wand', 'lumos (loo-mos)'),
(48, 'Morsmordre', 'Conjures and projects Lord Voldemort’s Dark Mark', 'morsmordre (morz-mor-druh)'),
(49, 'Mucus Ad Nauseam', 'Inflicts an extreme runny nose or cold', 'mucus ad nauseam (myoo-kuhs ad naw-zee-uhm)'),
(50, 'Muffliato', 'Creates a buzzing sound in the target’s ears to prevent eavesdropping', 'muffliato (muhf-lee-ah-toh)'),
(51, 'Nox', 'Reverses the lumos charm, extinguishing a wand’s light', 'nox (noks)'),
(52, 'Obliviate', 'Erases the target’s memory', 'obliviate (uh-bliv-ee-ayt)'),
(53, 'Obscuro', 'Conjures a blindfold', 'obscurus (ob-skew-roh)'),
(54, 'Oculus Reparo', 'Repairs eyeglasses', 'oculus reparo (ok-yuh-lus reh-par-oh)'),
(55, 'Oppugno', 'Directs an object or person to attack a victim', 'oppugno (op-uhg-noh)'),
(56, 'Petrificus Totalus', 'Temporarily freezes or petrifies the body of the target', 'petrificus totalus (peh-truh-fahy-kuhs toh-tah-luhs)'),
(57, 'Periculum', 'Conjures flares/red sparks', 'periculum (peh-rih-kyoo-lum)'),
(58, 'Piertotum Locomotor', 'Incantation used to bring to life inanimate objects and artifacts', 'piertotum locomotor (peer-toh-tuhm loh-kuh-moh-tor)'),
(59, 'Protean Charm', 'Links objects together for better communication', 'protean charm (proh-tee-uhn charm)'),
(60, 'Protego', 'Casts an invisible shield around the caster, protecting against spells and objects', 'protego (proh-tee-goh)'),
(61, 'Reducto', 'Reduces the target to pieces', 'reducto (ri-duhk-toh)'),
(62, 'Reducio', 'Shrinks an enlarged object to its regular size', 'reducio (ri-doo-see-oh)'),
(63, 'Renneverate', 'Awakens or revives the target', 'renneverate (ren-eh-ver-ate)'),
(64, 'Reparifors', 'Heals magical ailments like poisoning or paralysis', 'reparifors (reh-par-ee-fors)'),
(65, 'Reparo', 'Fixes broken objects', 'reparo (reh-pah-roh)'),
(66, 'Rictusempra', 'A charm that disarms an opponent by tickling them', 'rictusempra (rik-too-sem-pra)'),
(67, 'Riddikulus', 'Used to detect a Boggart, the charm allows the scary creature to assume a comedic form, disarming it', 'riddikulus (rih-dik-yuh-lus)'),
(68, 'Scourgify', 'Cleans objects', 'scourgify (skur-jih-fahy)'),
(69, 'Sectumsempra', 'Inflicts severe lacerations and hemorrhaging on the target', 'sectumsempra (sehk-tuhm-semp-ruh)'),
(70, 'Serpensortia', 'Conjures a live snake', 'serpensortia (ser-pen-sor-tee-uh)'),
(71, 'Silencio', 'Silences the target', 'silencio (sih-len-see-oh)'),
(72, 'Sonorus', 'Amplifies the witch or wizard’s voice', 'sonorus (soh-noh-ruhs)'),
(73, 'Spongify', 'Softens the target', 'spongify (spuhn-jih-fy)'),
(74, 'Stupefy', 'The Stunning spell freezes objects and renders living targets unconscious', 'stupefy (stoo-puh-fahy)'),
(75, 'Tarantallegra', 'Aimed at the legs, causes uncontrollable dancing movement', 'tarantallegra (tuh-ran-tuh-leh-gruh)'),
(76, 'Unbreakable Vow', 'A magically binding contract that results in the death of whoever breaks it', 'unbreakable vow (uhn-brey-kuh-buhl voh)'),
(77, 'Wingardium Leviosa', 'Causes an object to levitate', 'wingardium leviosa (win-gar-dee-um leh-vee-oh-sah)');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `options`
--

TRUNCATE TABLE `options`;
--
-- Dumping data for table `options`
--

INSERT DELAYED IGNORE INTO `options` (`id`, `question_id`, `option_text`, `is_correct`) VALUES
(1, 1, 'Expelliarmus', 1),
(2, 1, 'Incendio', 0),
(3, 1, 'Wingardium Leviosa', 0),
(4, 1, 'Lumos', 0),
(5, 2, 'Avada Kedavra', 0),
(6, 2, 'Expecto Patronum', 0),
(7, 2, 'Lumos', 1),
(8, 2, 'Alohomora', 0),
(9, 3, 'Accio', 1),
(10, 3, 'Imperio', 0),
(11, 3, 'Obliviate', 0),
(12, 3, 'Petrificus Totalus', 0),
(13, 4, 'Wingardium Leviosa', 0),
(14, 4, 'Crucio', 0),
(15, 4, 'Expelliarmus', 0),
(16, 4, 'Alohomora', 1),
(17, 5, 'Protego', 1),
(18, 5, 'Stupefy', 0),
(19, 5, 'Petrificus Totalus', 0),
(20, 5, 'Incendio', 0),
(21, 6, 'Avada Kedavra', 0),
(22, 6, 'Wingardium Leviosa', 1),
(23, 6, 'Expecto Patronum', 0),
(24, 6, 'Accio', 0),
(25, 7, 'Protego', 0),
(26, 7, 'Expecto Patronum', 1),
(27, 7, 'Expelliarmus', 0),
(28, 7, 'Petrificus Totalus', 0),
(29, 8, 'Aguamenti', 1),
(30, 8, 'Lumos', 0),
(31, 8, 'Alohomora', 0),
(32, 8, 'Sectumsempra', 0),
(33, 9, 'Incendio', 0),
(34, 9, 'Reparo', 1),
(35, 9, 'Accio', 0),
(36, 9, 'Imperio', 0),
(37, 10, 'Levicorpus', 1),
(38, 10, 'Expelliarmus', 0),
(39, 10, 'Petrificus Totalus', 0),
(40, 10, 'Stupefy', 0),
(41, 11, 'Expelliarmus', 0),
(42, 11, 'Protego', 1),
(43, 11, 'Stupefy', 0),
(44, 11, 'Avada Kedavra', 0),
(45, 12, 'Petrificus Totalus', 1),
(46, 12, 'Wingardium Leviosa', 0),
(47, 12, 'Lumos', 0),
(48, 12, 'Obliviate', 0),
(49, 13, 'Alohomora', 0),
(50, 13, 'Expecto Patronum', 0),
(51, 13, 'Imperio', 1),
(52, 13, 'Incendio', 0),
(53, 14, 'Crucio', 1),
(54, 14, 'Accio', 0),
(55, 14, 'Reparo', 0),
(56, 14, 'Aguamenti', 0),
(57, 15, 'Reducto', 0),
(58, 15, 'Gemino', 1),
(59, 15, 'Lumos', 0),
(60, 15, 'Incarcerous', 0),
(61, 16, 'Incendio', 0),
(62, 16, 'Petrificus Totalus', 0),
(63, 16, 'Serpensortia', 0),
(64, 16, 'Incarcerous', 1),
(65, 17, 'Expelliarmus', 0),
(66, 17, 'Lumos', 0),
(67, 17, 'Stupefy', 0),
(68, 17, 'Serpensortia', 1),
(69, 18, 'Expelliarmus', 0),
(70, 18, 'Aguamenti', 0),
(71, 18, 'Expecto Patronum', 0),
(72, 18, 'Incendio', 1),
(73, 19, 'Obliviate', 1),
(74, 19, 'Accio', 0),
(75, 19, 'Imperio', 0),
(76, 19, 'Reparo', 0),
(77, 20, 'Ventus', 1),
(78, 20, 'Aguamenti', 0),
(79, 20, 'Wingardium Leviosa', 0),
(80, 20, 'Petrificus Totalus', 0),
(81, 21, 'Incarcerous', 1),
(82, 21, 'Wingardium Leviosa', 0),
(83, 21, 'Petrificus Totalus', 0),
(84, 21, 'Lumos', 0),
(85, 22, 'Evanesco', 1),
(86, 22, 'Lumos', 0),
(87, 22, 'Stupefy', 0),
(88, 22, 'Reducto', 0),
(89, 23, 'Avis', 1),
(90, 23, 'Accio', 0),
(91, 23, 'Obliviate', 0),
(92, 23, 'Engorgio', 0),
(93, 24, 'Muffliato', 0),
(94, 24, 'Petrificus Totalus', 0),
(95, 24, 'Silencio', 1),
(96, 24, 'Levicorpus', 0),
(97, 25, 'Vera Verto', 1),
(98, 25, 'Engorgio', 0),
(99, 25, 'Reducio', 0),
(100, 25, 'Lumos', 0),
(101, 26, 'Sonorus', 1),
(102, 26, 'Reparo', 0),
(103, 26, 'Petrificus Totalus', 0),
(104, 26, 'Crucio', 0),
(105, 27, 'Locomotor Mortis', 0),
(106, 27, 'Incarcerous', 1),
(107, 27, 'Aguamenti', 0),
(108, 27, 'Gemino', 0),
(109, 28, 'Reducto', 0),
(110, 28, 'Aguamenti', 0),
(111, 28, 'Repello Muggletum', 1),
(112, 28, 'Wingardium Leviosa', 0),
(113, 29, 'Aguamenti', 1),
(114, 29, 'Lumos', 0),
(115, 29, 'Alohomora', 0),
(116, 29, 'Ventus', 0),
(117, 30, 'Wingardium Leviosa', 1),
(118, 30, 'Accio', 0),
(119, 30, 'Expelliarmus', 0),
(120, 30, 'Expecto Patronum', 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `questions`
--

TRUNCATE TABLE `questions`;
--
-- Dumping data for table `questions`
--

INSERT DELAYED IGNORE INTO `questions` (`id`, `question_text`) VALUES
(1, 'What spell is used to disarm an opponent?'),
(2, 'Which spell creates light at the tip of the caster\'s wand?'),
(3, 'What spell is used to summon an object to the caster?'),
(4, 'Name the spell used for unlocking doors and other locked objects.'),
(5, 'Which spell creates a temporary barrier around the caster?'),
(6, 'What spell is used to levitate objects?'),
(7, 'Name the spell used to repel Dementors.'),
(8, 'Which spell produces a jet of water from the caster\'s wand?'),
(9, 'What spell is used to mend broken objects?'),
(10, 'Name the spell that causes the victim\'s legs to knot together.'),
(11, 'Which spell creates a shield against incoming spells?'),
(12, 'What spell is used to immobilize the target?'),
(13, 'Name the spell that can control someone\'s actions.'),
(14, 'What spell causes intense pain to the victim?'),
(15, 'Which spell causes an object to multiply?'),
(16, 'Name the spell used to create a temporary body bind.'),
(17, 'What spell creates a snake from the caster\'s wand?'),
(18, 'Which spell produces a jet of fire from the caster\'s wand?'),
(19, 'Name the spell used to erase memories.'),
(20, 'What spell produces a blast of wind from the caster\'s wand?'),
(21, 'Which spell immobilizes the target by binding their body tightly?'),
(22, 'Name the spell used to vanish objects.'),
(23, 'What spell summons a flock of birds?'),
(24, 'Which spell binds the target\'s tongue to prevent speech?'),
(25, 'Name the spell used to transform an object into a cup.'),
(26, 'What spell creates a temporary distraction by producing a loud noise?'),
(27, 'Which spell creates a rope to bind or tie someone up?'),
(28, 'Name the spell used to repel water.'),
(29, 'What spell produces a stream of water from the caster\'s wand?'),
(30, 'Which spell causes objects to levitate and move according to the caster\'s will?');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE IF NOT EXISTS `quizzes` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `option_a` varchar(50) NOT NULL,
  `option_b` varchar(50) NOT NULL,
  `option_c` varchar(50) NOT NULL,
  `option_d` varchar(50) NOT NULL,
  `answer` varchar(50) NOT NULL,
  PRIMARY KEY (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `quizzes`
--

TRUNCATE TABLE `quizzes`;
--
-- Dumping data for table `quizzes`
--

INSERT DELAYED IGNORE INTO `quizzes` (`quiz_id`, `question`, `option_a`, `option_b`, `option_c`, `option_d`, `answer`) VALUES
(1, 'What spell is used to disarm an opponent?', 'Wingardium Leviosa', 'Expelliarmus', 'Lumos', 'Incendio', 'Expelliarmus'),
(2, 'Which spell creates light at the tip of the caster\'s wand?', 'Avada Kedavra', 'Expecto Patronum', 'Lumos', 'Alohomora', 'Lumos'),
(3, 'What spell is used to summon an object to the caster?', 'Accio', 'Imperio', 'Obliviate', 'Petrificus Totalus', 'Accio'),
(4, 'Name the spell used for unlocking doors and other locked objects.', 'Wingardium Leviosa', 'Crucio', 'Expelliarmus', 'Alohomora', 'Alohomora'),
(5, 'Which spell creates a temporary barrier around the caster?', 'Protego', 'Stupefy', 'Incendio', 'Petrificus Totalus', 'Protego'),
(6, 'What spell is used to levitate objects?', 'Avada Kedavra', 'Wingardium Leviosa', 'Expecto Patronum', 'Wingardium Leviosa', 'Wingardium Leviosa'),
(7, 'Name the spell used to repel Dementors.', 'Expecto Patronum', 'Petrificus Totalus', 'Expecto Patronum', 'Protego', 'Expecto Patronum'),
(8, 'Which spell produces a jet of water from the caster\'s wand?', 'Aguamenti', 'Lumos', 'Alohomora', 'Sectumsempra', 'Aguamenti'),
(9, 'What spell is used to mend broken objects?', 'Incendio', 'Reparo', 'Accio', 'Imperio', 'Reparo'),
(10, 'Name the spell that causes the victim\'s legs to knot together.', 'Levicorpus', 'Expelliarmus', 'Stupefy', 'Petrificus Totalus', 'Levicorpus'),
(11, 'Which spell creates a shield against incoming spells?', 'Avada Kedavra', 'Protego', 'Stupefy', 'Petrificus Totalus', 'Protego'),
(12, 'What spell is used to immobilize the target?', 'Petrificus Totalus', 'Wingardium Leviosa', 'Jotalus', 'Lumos', 'Petrificus Totalus'),
(13, 'Name the spell that can control someone\'s actions.', 'Expecto Patronum', 'Imperio', 'Alohomora', 'Incendio', 'Imperio'),
(14, 'What spell causes intense pain to the victim?', 'Crucio', 'Accio', 'Reparo', 'Aguamenti', 'Crucio'),
(15, 'Which spell causes an object to multiply?', 'Reducto', 'Gemino', 'Lumos', 'Incarcerous', 'Gemino'),
(16, 'Name the spell used to create a temporary body bind.', 'Incendio', 'Petrificus Totalus', 'Serpensortia', 'Incarcerous', 'Incarcerous'),
(17, 'What spell creates a snake from the caster\'s wand?', 'Expelliarmus', 'Lumos', 'Stupefy', 'Serpensortia', 'Serpensortia'),
(18, 'Which spell produces a jet of fire from the caster\'s wand?', 'Expecto Patronum', 'Aguamenti', 'Expecto Patronum', 'Incendio', 'Incendio'),
(19, 'Name the spell used to erase memories.', 'Obliviate', 'Accio', 'Imperio', 'Reparo', 'Obliviate'),
(20, 'What spell produces a blast of wind from the caster\'s wand?', 'Wingardium Leviosa', 'Petrificus Totalus', 'Ventus', 'Aguamenti', 'Ventus'),
(21, 'What spell immobilizes the target by binding their body tightly?', 'Incarcerous', 'Wingardium Leviosa', 'Petrificus Totalus', 'Lumos', 'Incarcerous'),
(22, 'Name the spell used to vanish objects.', 'Evanesco', 'Lumos', 'Stupefy', 'Reducto', 'Evanesco'),
(23, 'What spell summons a flock of birds?', 'Avis', 'Accio', 'Obliviate', 'Engorgio', 'Avis'),
(24, 'Which spell binds the target\'s tongue to prevent speech?', 'Petrificus Totalus', 'Muffliato', 'Silencio', 'Lexicorpus', 'Silencio'),
(25, 'Name the spell used to transform an object into a cup', 'Vera Verto', 'Engorgio', 'Reducio', 'Lumos', 'Vera Verto'),
(26, 'What spell creates a temporary distraction by producing a loud noise?', 'Sonorus', 'Reparo', 'Petrificus Totalus', 'Crucio', 'Sonorus'),
(27, 'Which spell creates a rope to bind or tie someone up?', 'Locomotor Mortis', 'Incarcerous', 'Aguamenti', 'Gemino', 'Incarcerous'),
(28, 'Name the spell used to repel water.', 'Reducto', 'Aguamenti', 'Repello Muggletum', 'Wingardium Leviosa', 'Repello Muggletum'),
(29, 'What spell produces a stream of water from the caster\'s wand?', 'Aguamenti', 'Lumos', 'Alohomora', 'Ventus', 'Aguamenti'),
(30, 'Which spell causes objects to levitate and move according to the caster\'s will?', 'Wingardium Leviosa', 'Accio', 'Expelliarmus', 'Expecto Patronum', 'Wingardium Leviosa');

-- --------------------------------------------------------

--
-- Table structure for table `spells`
--

DROP TABLE IF EXISTS `spells`;
CREATE TABLE IF NOT EXISTS `spells` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `spells`
--

TRUNCATE TABLE `spells`;
--
-- Dumping data for table `spells`
--

INSERT DELAYED IGNORE INTO `spells` (`id`, `name`, `description`) VALUES
(1, 'Accio', 'Calls an object to you.'),
(2, 'Aguamenti', 'Water comes from your opponent’s wand.'),
(3, 'Alohomora', 'Opens locks.'),
(4, 'Aparecium', 'Turns invisible ink visible.'),
(5, 'Avada Kedavra', 'One of The Unforgivable Curses; Kills your opponent.'),
(6, 'Avifors', 'Turns a thing into a bird.'),
(7, 'Avis', 'Birds fly out of the end of your wand.'),
(8, 'Bombarda', 'Causes a small explosion.'),
(9, 'Colloportus', 'Closes a door and binds it so that it can’t be opened.'),
(10, 'Confringo', 'The Blasting Curse.'),
(11, 'Confundus', 'Confounds your target & makes them temporarily confused.'),
(12, 'Conjunctivitis', 'Damages the eyesight of your opponent.'),
(13, 'Crucio', 'The Second Unforgivable Curse, the Cruciatus Curse.'),
(14, 'Deletrius', 'Erases the last spell cast by a wand so that it can’t be discovered.'),
(15, 'Densaugeo', 'Makes teeth grow out of control.'),
(16, 'Diffindo', 'Makes seams split open.'),
(17, 'Dissendium', 'Opens a specific passageway into a cellar.'),
(18, 'Duro', 'Turns an item to stone.'),
(19, 'Engorgio', 'Makes an item larger.'),
(20, 'Episkey', 'Heals relatively minor wounds.'),
(21, 'Evanesco', 'Causes an item to immediately dissolve.'),
(22, 'Expecto Patronum', 'Creates a Patronus.'),
(23, 'Expelliarmus', 'Disarms the target of the spell.'),
(24, 'Ferula', 'Binds a broken limb.'),
(25, 'Fidelius', 'Allows a secret to be hidden within the secret keeper’s soul.'),
(26, 'Finite Incantatem', 'Stops any spell.'),
(27, 'Flagrate', 'Allows the user to write or draw in the air with fire.'),
(28, 'Flipendo', 'Also known as the Knockback Jinx.'),
(29, 'Furnunculus', 'Causes a person to break out in boils.'),
(30, 'Geminio', 'Creates a duplicate of an item.'),
(31, 'Homorphus', 'Man-Shape; makes a person disguised as an animal resume their human shape.'),
(32, 'Immobulus', 'Immobilizes the target.'),
(33, 'Impedimenta', 'Puts up an impediment that slows down something or someone that is coming toward you.'),
(34, 'Imperio', 'The third unforgivable curse. Allows the user to assume complete control of another person.'),
(35, 'Impervius', 'Repels water from a surface.'),
(36, 'Incarcerous', 'Conjures up ropes, which then bind an opponent.'),
(37, 'Incendio', 'Lights a fire.'),
(38, 'Legilimens', 'Allows the user to gain access to another’s mind.'),
(39, 'Levicorpus', 'Turns your opponent upside down.'),
(40, 'Liberacorpus', '“Liberates”, or frees a body that has been caught up by the levicorpus spell.'),
(41, 'Locomotor Mortis', 'The Leg-Locker Curse; locks an opponent’s legs together.'),
(42, 'Lumos', 'Creates light, usually by making the tip of the wand glow.'),
(43, 'Mobiliarbus', 'Used to move a tree from one place to another.'),
(44, 'Mobilicorpus', 'Used to move a body from one place to another.'),
(45, 'Morsmordre or Morsmorde', 'Used to summon the Dark Mark.'),
(46, 'Muffliato', 'Causes a buzzing noise so that those in the area can carry on a private conversation.'),
(47, 'Nox', 'Extinguishes light as created by “Lumos”.'),
(48, 'Obliviate', 'Erases a memory.'),
(49, 'Orchideous', 'Conjures a bunch of flowers from the user’s wand.'),
(50, 'Petrificus Totalus', 'Total petrification.'),
(51, 'Portus', 'Turns any item into a Portkey, which can then be used to transport a person or persons to another location.'),
(52, 'Prior Incantato', 'Reveals to you the last spell that a wand was used to cast.'),
(53, 'Protego', 'Sends a spell back on an opponent.'),
(54, 'Quietus', 'Makes things quiet, used to muffle “Sonorus”.'),
(55, 'Reducio', 'Shrinks an item.'),
(56, 'Reducto', 'Blasts something to pieces.'),
(57, 'Relashio', 'Releases something.'),
(58, 'Reparo', 'Repairs broken items.'),
(59, 'Repello', 'Repels something.'),
(60, 'Repello Muggletum', 'Makes an area invisible to Muggles.'),
(61, 'Revelio', 'Causes something that is hidden to be revealed.'),
(62, 'Rictusempra', 'Causes a person to curl up in laughter.'),
(63, 'Riddikulus', 'Makes a boggart funny rather than terrifying.'),
(64, 'Salvio Hexia', 'Protective spell against hexes.'),
(65, 'Scourgify', 'Used to clean dirt off.'),
(66, 'Sectumsempra', 'Causes cuts to appear all over an opponent’s body.'),
(67, 'Serpensortia', 'Calls a snake.'),
(68, 'Silencio', 'Makes the target of the spell unable to make any sound.'),
(69, 'Sonorus', 'Amplifies the user’s voice.'),
(70, 'Stupefy', 'Stupefies an opponent.'),
(71, 'Tarantallegra', 'Forces an opponent’s legs to dance.'),
(72, 'Tergeo', 'Scours something clean.'),
(73, 'Waddiwasi', 'Removes a stuck object.'),
(74, 'Wingardium Leviosa', 'Levitates objects.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_name` (`user_name`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT DELAYED IGNORE INTO `users` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 66662477, 'user123', 'user123', '2024-04-27 10:59:13'),
(3, 9223372036854775807, 'judith', 'abraham', '2024-04-27 11:45:47'),
(4, 278411, 'nazrin', 'farhana', '2024-04-29 04:13:55'),
(5, 6986033, 'judith', '1234', '2024-04-29 04:30:29'),
(6, 9089194533340977901, 'user12345', 'hello', '2024-04-29 04:30:54'),
(7, 59437240782, 'harry', 'styles', '2024-05-04 12:52:13'),
(8, 7179127278, 'user12345', 'user1234', '2024-05-04 12:54:48'),
(9, 39205233567371, 'ashwini', 'abraham', '2024-05-04 13:48:39'),
(10, 357254733944926588, 'alia', 'bhatt', '2024-05-06 14:53:27'),
(11, 9311, 'gopika', '1234', '2024-05-07 06:41:16'),
(12, 9223372036854775807, 'khadeeja', 'najeem', '2024-05-09 07:27:01'),
(13, 60551954, 'khadeeja', 'najeem', '2024-05-09 07:27:37'),
(14, 8202890043385714, 'khadeeja', 'najeem', '2024-05-09 08:44:16'),
(15, 788528582498, 'maria', 'maria', '2024-05-09 08:56:15'),
(16, 5412218215829310, 'priyanka', 'chopra', '2024-05-09 09:10:48'),
(17, 773978, 'haritha', 'haritha', '2024-05-09 09:26:44'),
(18, 32, 'kaju', 'barfi', '2024-05-09 09:38:12');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `highscores`
--
ALTER TABLE `highscores`
  ADD CONSTRAINT `highscores_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `games` (`game_id`),
  ADD CONSTRAINT `highscores_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`);

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `FK_question_quiz` FOREIGN KEY (`id`) REFERENCES `quizzes` (`quiz_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Know More</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('educatewall.JPG');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            text-align: center;
            color: white;
        }

        .navigation {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px 0;
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .navigation a:hover {
            text-decoration: underline;
        }

        .content {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
            margin: 20px auto;
            max-width: 600px;
        }

        h1, p {
            color: white;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        a.button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }

        a.button:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
<div class="navigation">
    <a href="home.php">Home</a>
    <a href="logout.php">Logout</a>
    <a href="playgames.php">Play Games</a>
    <a href="contact_us.html">Contact Us</a>
</div>
<div class="content">
    <h1>Educate Yourself About Harry Potter</h1>
    <p>Welcome to the magical world of Harry Potter! Explore the enchanting characters, learn fascinating spells, and discover each of the series' reviews from the wizarding world.</p>
    <p>Hello, <?php echo $user_data['user_name']; ?>!</p><br>
    <a href="characters.html" class="button">Know More About The Characters</a><br>
    <a href="caster.php" class="button">Spellcaster's Apprentice - Learn The Spells</a><br>
    <a href="seriesreview.html" class="button">Series Review</a><br>
</div>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <title>EXPECTOARCANA</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('indexwallpaper.jpg'); /* Replace 'indexwallpaper.jpg' with your background image URL */
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: 'Arial', sans-serif;
        }
        #explore_button {
            padding: 15px 30px;
            font-size: 20px;
            background-color: #990000;
            border: 2px solid #ffcc00;
            border-radius: 10px;
            cursor: pointer;
            color: #ffcc00;
            text-decoration: none;
            text-transform: uppercase;
            transition: all 0.3s ease;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3);
        }
        #explore_button:hover {
            background-color: #ffcc00;
            color: #990000;
            border-color: #990000;
        }
    </style>
</head>
<body>
<audio autoplay loop controls style="position: fixed; bottom: 10px; right: 10px; width: 100px; background-color: black;">
  <source src="Hedwig's Theme.mp3" type="audio/mpeg">
</audio>


    <a id="explore_button" href="login.php">Explore</a>
</body>
</html>

<?php
session_start();
include("connection.php");
include("functions.php");


if (isset($_POST['optionId']) && isset($_SESSION['question_number'])) {
    $selectedOptionId = $_POST['optionId'];
    $questionId = $_SESSION['question_number'];

    // Fetch the option and check if it is the correct one
    $stmt = $con->prepare("SELECT is_correct FROM options WHERE id = ?");
    $stmt->bind_param("i", $selectedOptionId);
    $stmt->execute();
    $result = $stmt->get_result();
    $selectedOption = $result->fetch_assoc();

    if ($selectedOption['is_correct']) {
        $_SESSION['feedback'] = "Correct answer!";
        $_SESSION['correct_count'] = isset($_SESSION['correct_count']) ? $_SESSION['correct_count'] + 1 : 1;
    } else {
        $_SESSION['feedback'] = "Wrong answer!";
    }

    // Only increment total questions when an answer is submitted
    $_SESSION['total_questions'] = isset($_SESSION['total_questions']) ? $_SESSION['total_questions'] + 1 : 1;

    // Check if it's over the total questions available
    $stmt = $conn->prepare("SELECT COUNT(id) AS total_questions FROM questions");
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    $_SESSION['question_number']++;

    if ($_SESSION['question_number'] > $data['total_questions']) {
        header("Location: finish.php");
    } else {
        header("Location: quiz.php");
    }
    exit;
}

// Redirect back if no data submitted
header("Location: index.html");
exit;
?>

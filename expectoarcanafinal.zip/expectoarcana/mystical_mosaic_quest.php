<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mystical Mosaic Quest</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      margin: 0;
      padding: 0;
    }

    #board {
      width: 360px;
      height: 360px;
      background-color: lightblue;
      border: 10px solid blue;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
    }

    #board img {
      width: 118px;
      height: 118px;
      border: 1px solid blue;
    }

    .navigation {
      background-color: #000;
      padding: 10px 0;
    }

    .navigation a {
      color: #fff;
      text-decoration: none;
      margin: 0 10px;
    }

    .navigation a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="navigation">
    <a href="home.php">Home</a>
    <a href="logout.php">Logout</a>
    <a href="knowmore.html">Educate Yourself</a>
    <a href="contact_us.html">Contact</a>
    <a href="playgames.php">Quit Game</a>
  </div>
  <h1>Mystical Mosaic Quest</h1>
  <h2>Hello, <?php echo $user_data['user_name']; ?>!</h2>
  <p> <i> Don't drag the image tiles instead click the image tile you want to move</i></p>
  <div id="board"></div>
  <h1>Turns: <span id="turns">0</span></h1>
  <button id="hintButton" onclick="showHint()">Show Hint</button>
  <div id="hint" style="display: none;">
    <img src="puzzle.jpeg" alt="Solved Image">
  </div>
  <div id="congrats" style="display: none;">
    <h2>Congratulations!</h2>
    <p>You've solved the puzzle!</p>
  </div>
  <script>
    var rows = 3;
    var columns = 3;

    var currTile;
    var otherTile; //blank tile

    var turns = 0;

    var imgOrder = ["4", "2", "6", "1", "5", "3", "7", "8", "9"];
    var solvedOrder = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];

    window.onload = function () {
      createBoard();
    }

    function createBoard() {
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < columns; c++) {
          let tile = document.createElement("img");
          tile.id = r.toString() + "-" + c.toString();
          tile.src = imgOrder.shift() + ".jpg";
          tile.addEventListener("click", moveTile);
          document.getElementById("board").append(tile);
        }
      }
    }

    function moveTile() {
      currTile = this;

      let currCoords = currTile.id.split("-");
      let r = parseInt(currCoords[0]);
      let c = parseInt(currCoords[1]);

      let neighbors = [];

      if (r > 0) neighbors.push(document.getElementById((r - 1) + "-" + c)); // Top neighbor
      if (r < rows - 1) neighbors.push(document.getElementById((r + 1) + "-" + c)); // Bottom neighbor
      if (c > 0) neighbors.push(document.getElementById(r + "-" + (c - 1))); // Left neighbor
      if (c < columns - 1) neighbors.push(document.getElementById(r + "-" + (c + 1))); // Right neighbor

      for (let i = 0; i < neighbors.length; i++) {
        if (neighbors[i].src.includes("3.jpg")) {
          otherTile = neighbors[i];
          swapTiles();
          break;
        }
      }
    }

    function swapTiles() {
      let currImg = currTile.src;
      let otherImg = otherTile.src;

      currTile.src = otherImg;
      otherTile.src = currImg;

      turns++;
      document.getElementById("turns").innerText = turns;

      checkWin();
    }

    function checkWin() {
      let imgs = document.getElementById("board").getElementsByTagName("img");
      let correctOrder = true;
      for (let i = 0; i < imgs.length; i++) {
        if (!imgs[i].src.endsWith(solvedOrder[i] + ".jpg")) {
          correctOrder = false;
          break;
        }
      }
      if (correctOrder) {
        document.getElementById("congrats").style.display = "block";
      }
    }

    function showHint() {
      document.getElementById("hint").style.display = "block";
    }
  </script>
</body>
</html>

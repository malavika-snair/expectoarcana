<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);

if (isset($_POST['startQuiz'])) {
    $_SESSION['question_number'] = 1;  // Start from the first question
    $_SESSION['total_questions'] = 0;  // Reset total questions each time quiz is started
    $_SESSION['correct_count'] = 0;    // Reset correct answers count
    $_SESSION['asked_questions'] = []; // Reset or initialize the array to track asked questions
} elseif (isset($_POST['nextQuestion'])) {
    $_SESSION['question_number']++;
}

if (!isset($_SESSION['asked_questions'])) {
    $_SESSION['asked_questions'] = []; // Initialize if not already set
}

// Randomly fetch a question that hasn't been asked yet
do {
    $questionQuery = "SELECT * FROM questions ORDER BY RAND() LIMIT 1";
    $result = $con->query($questionQuery);
    $question = $result->fetch_assoc();
} while (in_array($question['id'], $_SESSION['asked_questions']) && count($_SESSION['asked_questions']) < (int)$con->query("SELECT COUNT(id) FROM questions")->fetch_row()[0]);

// Add the current question ID to the asked questions list
$_SESSION['asked_questions'][] = $question['id'];

// Fetch the options for the current question
$optionsQuery = "SELECT * FROM options WHERE question_id = {$question['id']}";
$optionsResult = $con->query($optionsQuery);
$options = $optionsResult->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz</title>
    <link rel="stylesheet" href="./css/style_quiz.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-image: url('quizwall.jpeg'); /* Background image */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the background image */
            background-attachment: fixed; /* Fixed background image */
        }

        .navigation {
            background-color: rgba(0, 0, 0, 0.7); /* Transparent black background */
            padding: 10px 0;
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .navigation a:hover {
            text-decoration: underline;
        }

        .quiz-container {
            background-color: rgba(255, 255, 255, 0.7); /* Transparent white background */
            padding: 20px;
            border-radius: 10px;
            margin: 10px auto; /* Reduced margin */
            max-width: 600px;
        }

        .options-container {
            margin-top: 20px;
        }

        .option {
            margin-bottom: 10px;
            background-color: transparent;
            color: #000;
            border: 2px solid #000;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .option:hover {
            background-color: #000;
            color: #fff;
        }

        .score {
            font-size: 18px;
            font-weight: bold;
        }

        .finish-quiz-btn,
        .submit-answer-btn {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: transparent;
            color: #000;
            border: 2px solid #000;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .finish-quiz-btn:hover,
        .submit-answer-btn:hover {
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>
<div class="navigation">
    <a href="home.php">Home</a>
    <a href="logout.php">Logout</a>
    <a href="knowmore.html">Educate Yourself</a>
    <a href="contact_us.html">Contact</a>
    <a href="playgames.php">Quit Game</a>
</div>
<div class="quiz-container"> <!-- New container for the quiz -->
    <h1>Quizzical</h1>
    <h2><i>Test Your Knowledge On Spells</i></h2>
    <h2>Hi <?php echo htmlspecialchars($user_data['user_name']); ?>, here is your question <?php echo $_SESSION['question_number']; ?>:</h2>
    <h3><?php echo htmlspecialchars($question['question_text']); ?></h3><br><br>
    <div class="score">Score: <?php echo (isset($_SESSION['correct_count']) ? $_SESSION['correct_count'] : 0); ?> / <?php echo (isset($_SESSION['total_questions']) ? $_SESSION['total_questions'] : 0); ?></div><br><br>
    <div class="options-container"> <!-- Container for options -->
        <?php foreach ($options as $option): ?>
            <button type="button" class="option" onclick="selectOption(this, <?php echo $option['id']; ?>, <?php echo $option['is_correct'] ? 'true' : 'false'; ?>)" data-correct="<?php echo $option['is_correct'] ? 'true' : 'false'; ?>">
                <?php echo htmlspecialchars($option['option_text']); ?>
            </button><br><br>
        <?php endforeach; ?><br>
        <button type="button" class="finish-quiz-btn" onclick="finishQuiz()">Finish Quiz</button>
        <button type="button" class="submit-answer-btn" id="actionButton" onclick="submitAnswer()">Submit Answer</button>
    </div>

    <div id="response" style="color: red; font-size: 16px; margin-top: 20px;"></div>
</div>
<script>
    let selectedOption = null;

    function selectOption(button, optionId, isCorrect) {
        const options = document.querySelectorAll('.option');
        options.forEach(opt => {
            opt.classList.remove('selected', 'correct', 'incorrect'); // Clear previous selections and feedback
        });

        // Highlight the selected option
        button.classList.add('selected');
        selectedOption = {button: button, id: optionId, isCorrect: isCorrect === true};
    }

    function updateScore(optionId) {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "check_answer.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
            if (this.status === 200) {
                const responseData = JSON.parse(this.responseText);
                const scoreElement = document.querySelector('.score');
                scoreElement.textContent = `Score: ${responseData.correct_count} / ${responseData.total_questions}`;
            }
        };
        xhr.send(`optionId=${optionId}`);
    }


    function submitAnswer() {
        const responseElement = document.getElementById('response');
        let responseText = ""; // Declare the variable to hold your response text

        if (selectedOption) {
            // Update the score first
            updateScore(selectedOption.id);

            // Then handle the feedback and UI updates
            document.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected', 'correct', 'incorrect'));
            selectedOption.button.classList.add(selectedOption.isCorrect ? 'correct' : 'incorrect');

            if (!selectedOption.isCorrect) {
                document.querySelectorAll('.option[data-correct="true"]').forEach(button => {
                    button.classList.add('correct'); // Highlight the correct answer
                });
                responseText = `Wrong Answer! `; // Set the response text to be spoken
            } else {
                responseText = `${selectedOption.button.textContent} is the correct answer!`; // Set the response text to be spoken
            }

            responseElement.innerHTML = responseText; // Update the response text in the HTML
            speakResponse(responseText); // Speak out the response text

            // Update button functionality
            const actionButton = document.getElementById('actionButton');
            actionButton.textContent = 'Next Question';
            actionButton.onclick = function () {
                document.getElementById('nextQuestionForm').submit();
            };
        } else {
            responseText = "Please select an option before submitting."; // Alert text is set as response text
            alert(responseText); // Show the alert to the user
            speakResponse(responseText); // Speak out the alert
        }
    }


    function speakResponse(text) {
        if ('speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(text);
            speechSynthesis.speak(utterance);
        } else {
            console.error("TTS not supported in this browser.");
        }
    }

    function finishQuiz() {
        window.location.href = 'finish.php'; // Redirect to the finish page
    }
</script>

<form id="nextQuestionForm" method="POST">
    <input type="hidden" name="nextQuestion" value="1">
</form>
</body>
</html>

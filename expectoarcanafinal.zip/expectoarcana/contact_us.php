<?php
// Include connection.php and functions.php
include 'connection.php';
include 'functions.php';

// Check if form fields are set and not empty
if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['message'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Validate form data
    if (strlen($name) < 3) {
        echo 'Your name should be at least 3 characters long.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Please enter a valid email address.';
    } elseif (strlen($message) < 15) {
        echo 'Please write a longer message.';
    } else {
        // Insert form data into database
        $sql = "INSERT INTO contact_us (name, email, message) VALUES ('$name', '$email', '$message')";
        if (mysqli_query($con, $sql)) {
            echo 'success';
        } else {
            echo 'Error: ' . mysqli_error($con);
        }
    }
} else {
    echo 'All fields are required.';
}
?>

<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expecto Arcana: The Wizarding Adventure</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('homewall.jpg'); /* Replace 'homewall.jpg' with your background image URL */
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            font-family: 'Bookman Old Style', sans-serif; /* Change font to Bookman Old Style */
            color: #fff;
        }
        .container {
            text-align: center;
            padding-top: 100px;
        }
        h1 {
            font-size: 48px;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        h2 {
            font-size: 28px;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        p {
            font-size: 18px;
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
        .welcome-paragraph {
            font-style: italic;
            text-align: left;
            margin-bottom: 30px;
            padding: 0 20px;
        }
        nav {
            margin-top: 20px;
        }
        nav a {
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.3);
            transition: background-color 0.3s ease;
            display: inline-block;
        }
        nav a:hover {
            background-color: rgba(255, 255, 255, 0.5);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Expecto Arcana!</h1>
        <h2>The Wizarding Adventure</h2>
        <p>Hello, <?php echo $user_data['user_name']; ?>!</p>
        <p class="welcome-paragraph"><i>Welcome to Expecto Arcana, your one-stop shop for all things wizarding! Here, you can craft your own magical journey. Feeling adventurous? Challenge yourself with our interactive games like the thrilling "Wizarding Duel" or the brain-teasing "Mystical Mosaic Quest." Want to delve into the wizarding world? Explore the characters and spells that make Harry Potter so magical. Get ready to cast your learning spells and embark on an unforgettable adventure!</i></p>
        <nav>
            <a href="logout.php">Logout</a>
            <a href="playgames.php">Play Games</a>
            <a href="knowmore.php">Educate Yourself</a>
            <a href="contact_us.html">Contact Us</a>
        </nav>
    </div>
</body>
</html>

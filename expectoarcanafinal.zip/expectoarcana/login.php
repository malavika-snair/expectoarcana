<?php 

session_start();

include("connection.php");
include("functions.php");

$message = '';

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    // Something was posted
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {

        // Read from database
        $query = "SELECT * FROM users WHERE user_name = '$user_name' LIMIT 1";
        $result = mysqli_query($con, $query);

        if($result)
        {
            if($result && mysqli_num_rows($result) > 0)
            {

                $user_data = mysqli_fetch_assoc($result);
                
                if($user_data['password'] === $password)
                {

                    $_SESSION['user_id'] = $user_data['user_id'];
                    header("Location:home.php");
                    die;
                }
            }
        }
        
        $message = "Wrong username or password!";
    }else
    {
        $message = "Please enter valid username and password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('loginwallpaper.jpeg'); /* Replace 'background.jpg' with your background image URL */
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Bookman Old Style', sans-serif; /* Replace 'Bookman Old Style' with your font */
        }
        #login_box {
            background-color: rgba(255, 255, 255, 0.5);
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        #text, #button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.7);
        }
        #button {
            background-color: #990000;
            cursor: pointer;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 16px;
        }
        #button:hover {
            background-color: #ffcc00;
        }
        #message {
            color: red;
            margin-bottom: 10px;
            text-align: center;
        }
        #signup_text {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }
        #signup_link {
            text-decoration: none;
            color: #990000;
            font-weight: bold;
        }
    </style>
    <link href="https://fonts.googleapis.com/css2?family=Bookman+Old+Style&display=swap" rel="stylesheet">
</head>
<body>

    <div id="login_box">
        <form method="post">
            <div style="font-size: 20px; margin-bottom: 10px; text-align: center;">Login</div>

            <input id="text" type="text" name="user_name" placeholder="Username"><br>
            <input id="text" type="password" name="password" placeholder="Password"><br>

            <input id="button" type="submit" value="Login"><br>

            <div id="message"><?php echo $message; ?></div>
        </form>
        <div id="signup_text">New user? <a id="signup_link" href="signup.php">Click here to sign up</a></div>
    </div>
</body>
</html>


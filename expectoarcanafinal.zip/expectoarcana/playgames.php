<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome to the Gaming Zone</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-image: url('playgameswall.jpg');
            background-size: cover;
            color: #fff;
        }
        h1 {
            font-family: 'Harry Potter', cursive;
            font-size: 36px;
            margin-top: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        p {
            font-size: 18px;
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
        .container {
            margin-top: 50px;
        }
        .heading-box {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }
        .heading-box:hover {
            background-color: rgba(0, 0, 0, 0.9);
        }
        .game-table {
            display: table;
            width: 100%;
        }
        .game-row {
            display: table-row;
        }
        .game-cell {
            display: table-cell;
            padding: 10px;
            vertical-align: top;
            text-align: center;
        }
        .game-cell img {
            width: 250px;
            height: 250px;
            object-fit: cover;
            border: 2px solid #fff;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .game-cell img:hover {
            transform: scale(1.1);
        }
        .game-cell .text-box {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px;
            border-radius: 20px;
            margin-top: -30px;
            transition: all 0.3s ease;
        }
        .game-cell:hover .text-box {
            background-color: rgba(0, 0, 0, 0.9);
        }
        .game-cell .text-box h2 {
            color: #fff;
            margin: 0;
            font-size: 24px;
            border-bottom: 2px solid #fff;
            padding-bottom: 10px;
        }
        .game-cell .text-box p {
            color: #fff;
            margin: 20px 0 10px 0;
            font-size: 16px;
        }
        .game-cell button {
            margin-top: 10px;
            background-color: transparent;
            color: #fff;
            padding: 10px 20px;
            border: 2px solid #fff;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .game-cell button:hover {
            background-color: #fff;
            color: #000;
        }
        .navigation {
            background-color: #000;
            padding: 10px 0;
        }
        .navigation a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }
        .navigation a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="navigation">
    <a href="home.php">Home</a>
    <a href="logout.php">Logout</a>
    <a href="knowmore.html">Educate Yourself</a>
    <a href="contact_us.html">Contact</a>
</div>

<div class="heading-box">
    <h1>Welcome to the Gaming Zone</h1>
    <p>Hello, <?php echo $user_data['user_name']; ?>! Choose the game you want to play!</p>
</div>

<div class="container">
    <div class="game-table">
        <div class="game-row">
            <div class="game-cell">
                <img src="tictactoeicon.png" alt="Wizard's Duel: House Edition Tic TacToe"><br><br><br>
                <div class="text-box">
                    <h2>Wizard's Duel: Tic Tac Toe</h2>
                    <p>Play the classic game of Tic Tac Toe with a magical twist!</p>
                    <button onclick="window.location.href='wizard_duel.php'">Play</button>
                </div>
            </div>
            <div class="game-cell">
                <img src="mysticalicon.png" alt="Mystical Mosaic Quest"><br><br><br>
                <div class="text-box">
                    <h2>Mystical Mosaic Quest</h2>
                    <p>Embark on a magical adventure to solve mystical mosaics!</p>
                    <button onclick="window.location.href='mystical_mosaic_quest.php'">Play</button>
                </div>
            </div>
            <div class="game-cell">
                <img src="quizicon.png" alt="Quizzical"><br><br><br>
                <div class="text-box">
                    <h2>Quizzical</h2>
                    <p><i>Test your knowledge of the wizarding world with our magical quiz!</i></p>
                    <form action="quizzical.php" method="post">
                        <input type="hidden" name="startQuiz" value="1">
                        <button type="submit">Play</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

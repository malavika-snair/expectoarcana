<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "expectoarcana";

// Attempt to connect to MySQL database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select all spell names
$sql = "SELECT name, description FROM spells";
$result = $conn->query($sql);

$spells = [];
if ($result->num_rows > 0) {
    // Fetch all spell names and descriptions
    while($row = $result->fetch_assoc()) {
        $spells[] = $row; // Store the entire row
    }
} else {
    echo "0 results found";
}
$conn->close();
?>

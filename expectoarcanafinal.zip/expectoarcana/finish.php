<?php
session_start();
include("connection.php");
include("functions.php");

$username = $_SESSION['user_name'];
$correctCount = $_SESSION['correct_count'] ?? 0;
$totalQuestions = $_SESSION['total_questions'] ?? 0;

// Format the score to display
$scoreDisplay = "Your score is: {$correctCount} / {$totalQuestions}";

// Now you can destroy the session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quiz Finished</title>
    <link rel="stylesheet" href="./css/style_quiz.css">
</head>
<body>
    <h1></h1>
    <h2></h2><br>
    
    <div class="hp-quiz-container" id="startScreen">
        <h1 class="hp-quiz-title">Thank You <?php echo htmlspecialchars($username); ?> for playing!</h1>
        <h2 class="hp-quiz-title"><?php echo $scoreDisplay; ?></h2>
        <a href="playgames.php" ><button class="hp-quiz-button">Back To Play Games!</button></a>
    
    </div>
</body>
</html>

<?php
include("connection.php");

$sql = "SELECT spell_name, meaning, audio_file FROM magic";
$result = mysqli_query($con, $sql);

if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Spellcaster</title>
    <style>
        .spell-list {
            max-width: 600px;
            margin: 20px auto;
        }
        .spell-item {
            margin-bottom: 20px;
        }
        .spell-name {
            font-size: 18px;
            font-weight: bold;
        }
        .spell-meaning {
            font-style: italic;
        }
        .speak-button {
            padding: 5px 10px;
        }
    </style>
</head>
<body>
    <div class="spell-list">
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="spell-item">
                <p class="spell-name"><?php echo $row['spell_name']; ?></p>
                <p class="spell-meaning"><?php echo $row['meaning']; ?></p>
                <button class="speak-button" onclick="speak('<?php echo $row['audio_file']; ?>')"><?php echo $row['spell_name']; ?></button>
            </div>
        <?php endwhile; ?>
    </div>

    <script>
        function speak(audioFile) {
            var audio = new Audio("<?php echo $row['audio_file']; ?>");
            audio.play();
        }
    </script>
</body>
</html>

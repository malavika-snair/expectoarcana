<?php 
session_start();

include("connection.php");
include("functions.php");

$message = '';

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    // Something was posted
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {

        // Save to database
        $user_id = random_num(20);
        $query = "INSERT INTO users (user_id,user_name,password) VALUES ('$user_id','$user_name','$password')";

        mysqli_query($con, $query);

        header("Location: login.php");
        die;
    }else
    {
        $message = "Please enter some valid information!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('signupwallpaper.jpg'); /* Replace 'background.jpg' with your background image URL */
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Bookman Old Style', sans-serif; /* Replace 'Bookman Old Style' with your font */
        }
        #signup_box {
            background-color: rgba(255, 255, 255, 0.7);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        #text, #button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            border-radius: 5px;
        }
        #button {
            background-color: lightblue;
            cursor: pointer;
            font-weight: bold;
            color: #333;
        }
        #button:hover {
            background-color: #ffcc00;
        }
        #message {
            color: red;
            margin-bottom: 10px;
        }
        #login_link {
            color: #990000;
            font-weight: bold;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <div id="signup_box">
        <form method="post">
            <div style="font-size: 20px; margin-bottom: 10px;">Signup</div>

            <input id="text" type="text" name="user_name" placeholder="Username"><br>
            <input id="text" type="password" name="password" placeholder="Password"><br>

            <input id="button" type="submit" value="Signup"><br>

            <a id="login_link" href="login.php">Click to Login</a><br>
            <div id="message"><?php echo $message; ?></div>
        </form>
    </div>
</body>
</html>

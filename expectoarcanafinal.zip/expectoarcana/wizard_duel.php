<?php
session_start();
include("connection.php");
include("functions.php");

$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wizard Duel : Tic -Tac-Toe Game</title>

    <!-- Style CSS -->
    <link rel="stylesheet" href="./ttt_styles.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Harry+P&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Harry P', cursive;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            background-image: url('tttwall.jpeg');
            background-size: cover;
            background-position: center;
        }

        nav {
            background-color: #000;
            padding: 10px 0;
            margin-bottom: 20px;
            width: 100%;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin-right: 10px;
            padding: 5px 10px;
            border-radius: 5px;
        }

        nav a:hover {
            background-color: #fff;
            color: #000;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8);
            border: 2px solid #000;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .vs-button button {
            font-size: 20px;
            padding: 10px 20px;
            margin: 10px;
            border: 2px solid #000;
            border-radius: 10px;
            cursor: pointer;
            background-color: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
        }

        .vs-button button:hover {
            background-color: rgba(0, 0, 0, 0.9);
            color: #fff;
        }

        .game-board {
            margin-top: 20px;
        }

        .row {
            display: flex;
        }

        .cell {
            width: 100px;
            height: 100px;
            border: 2px solid #000;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            cursor: pointer;
            background-color: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
        }

        .cell:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }

        .winner-text {
            margin-top: 20px;
            font-size: 24px;
        }

        #restartButton {
            margin-top: 20px;
            font-size: 20px;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            background-color: rgba(0, 0, 0, 0.9);
            color: #fff;
            transition: all 0.3s ease;
        }

        #restartButton:hover {
            background-color: rgba(0, 0, 0, 0.7);
        }
    </style>
</head>
<body>
    
    <nav>
        <a href="home.php">Home</a>
        <a href="logout.php">Logout</a>
        <a href="playgames.php">Quit Game</a>
        <a href="knowmore.html">Educate Yourself</a>
        <a href="contact_us.html">Contact Us</a>
    </nav>

    <div class="container">
        <h1>Wizard Duel : Tic -Tac-Toe Game</h1>
        <h2>Hello, <?php echo $user_data['user_name']; ?>!</h2>

        <div class="vs-button">
            <button id="twoPlayers">2 Players</button>
            <button id="vsComputer">vs Computer</button>
        </div>

        <div class="game-section two-players" style="display: none;">
            <small>Player 1 = X || Player 2 = O</small>
            <div class="game-board">
                <div class="row">
                    <div class="cell" onclick="twoPMakeMove(0, 0)"></div>
                    <div class="cell" onclick="twoPMakeMove(0, 1)"></div>
                    <div class="cell" onclick="twoPMakeMove(0, 2)"></div>
                </div>
                <div class="row">
                    <div class="cell" onclick="twoPMakeMove(1, 0)"></div>
                    <div class="cell" onclick="twoPMakeMove(1, 1)"></div>
                    <div class="cell" onclick="twoPMakeMove(1, 2)"></div>
                </div>
                <div class="row">
                    <div class="cell" onclick="twoPMakeMove(2, 0)"></div>
                    <div class="cell" onclick="twoPMakeMove(2, 1)"></div>
                    <div class="cell" onclick="twoPMakeMove(2, 2)"></div>
                </div>
            </div>
            <p class="winner-text" id="twoPlayersWinnerText"></p>
        </div>

        <div class="game-section vs-computer" style="display: none;">
            <small>Player 1 = X || Computer = O</small>
            <div class="game-board">
                <div class="row">
                    <div class="cell" onclick="vsComMakeMove(0, 0)"></div>
                    <div class="cell" onclick="vsComMakeMove(0, 1)"></div>
                    <div class="cell" onclick="vsComMakeMove(0, 2)"></div>
                </div>
                <div class="row">
                    <div class="cell" onclick="vsComMakeMove(1, 0)"></div>
                    <div class="cell" onclick="vsComMakeMove(1, 1)"></div>
                    <div class="cell" onclick="vsComMakeMove(1, 2)"></div>
                </div>
                <div class="row">
                    <div class="cell" onclick="vsComMakeMove(2, 0)"></div>
                    <div class="cell" onclick="vsComMakeMove(2, 1)"></div>
                    <div class="cell" onclick="vsComMakeMove(2, 2)"></div>
                </div>
            </div>
            <p class="winner-text" id="vsComputerWinnerText"></p>
        </div>

        <button id="restartButton" onclick="restartGame()" style="display: none;">Restart Game</button>


    </div>

    <!-- Script JS -->
    <script src="./ttt_script.js"></script>
</body>
</html>



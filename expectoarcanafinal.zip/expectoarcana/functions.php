<?php

function check_login($con)
{
    if (isset($_SESSION['user_id']))
    {
        $id = $_SESSION['user_id'];
        // Use prepared statement to prevent SQL Injection
        $stmt = mysqli_prepare($con, "SELECT * FROM users WHERE user_id = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 's', $id); // 's' specifies the variable type => 'string'
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0)
        {
            $user_data = mysqli_fetch_assoc($result);
            $_SESSION['user_name'] = $user_data['user_name']; // Set the username in session here
            return $user_data;
        }
    }

    // Redirect to login if no valid session exists
    header("Location: login.php");
    die;
}


function random_num($length)
{

	$text = "";
	if($length < 5)
	{
		$length = 5;
	}

	$len = rand(4,$length);

	for ($i=0; $i < $len; $i++) { 
		# code...

		$text .= rand(0,9);
	}

	return $text;
}
<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = ""; // If you have set a password, put it here
$dbname = "expectoarcana";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

?>

<?php
include("get_data.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Harry Potter Spells</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #0e1a40; /* Dark blue background color */
            font-family: Arial, sans-serif;
            color: white; /* Change text color to white */
        }
        h1 {
            margin-top: 50px; /* Add some space from top */
            text-align: center; /* Center align the text */
        }
        h2 {
            margin-top: 60px; /* Add some space from top */
            text-align: center; /* Center align the text */
        }
        .navigation {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px 0;
            text-align: center; /* Center the navigation links */
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .navigation a:hover {
            text-decoration: underline;
        }

        .spell-list {
            max-width: 800px; /* Or any maximum width */
            margin: auto;
            padding: 10px;
        }
        .spell-item {
            display: flex;
            align-items: flex-start; /* Align items at the start */
            border-radius: 8px;
            padding: 10px;
            background-color: rgba(255, 255, 255, 0.2); /* Semi-transparent white background */
            margin-bottom: 10px;
        }
        .spell-description {
            flex: 1; /* Fill remaining space */
            margin-right: 20px; /* Space between text and button */
        }
        button {
            padding: 10px 20px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar HTML -->
<div class="navigation">
    <a href="home.php">Home</a>
    <a href="logout.php">Logout</a>
    <a href="playgames.php">Play Games</a>
    <a href="knowmore.php">Educate Yourself</a>
    <a href="contact_us.html">Contact Us</a>
</div>
<h1> Spellcaster's  Apprentice</h1>
<h2> Learn The Harry Potter Spells</h2>
    <div class="spell-list">
        <?php foreach($spells as $spell): ?>
            <div class="spell-item">
                <div class="spell-description">
                    <h3><?php echo $spell['name']; ?></h3>
                    <p><?php echo $spell['description']; ?></p>
                </div>
                <button onclick="speak('<?php echo addslashes($spell['name']) . ': ' . addslashes($spell['description']); ?>')">Speak</button>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
    function speak(textToSpeak) {
        var synth = window.speechSynthesis;
        var utterThis = new SpeechSynthesisUtterance(textToSpeak);
        synth.speak(utterThis);
    }
    </script>
</body>
</html>
